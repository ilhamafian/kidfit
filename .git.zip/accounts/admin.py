from django.contrib import admin
from .models import SizeCharts

admin.site.register(SizeCharts)
# Register your models here.
